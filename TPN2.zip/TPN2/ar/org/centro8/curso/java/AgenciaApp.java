package ar.org.centro8.curso.java;

import java.util.List;
import java.util.stream.Stream;

import ar.org.centro8.curso.java.entities.Auto;
import ar.org.centro8.curso.java.entities.Moto;
import ar.org.centro8.curso.java.entities.Vehiculo;

public class AgenciaApp {
    static Stream<Vehiculo> vehiculosStream = List.of(
            new Auto("Peugeot", "206", 200000.00f, 4),
            new Moto("Honda", "Titan", 60000.00f, 125),
            new Auto("Peugeot", "208", 250000.00f, 5),
            new Moto("Yamaha", "YBR", 80500.50f, 160))
            .stream(); 
    public static void main(String[] args) {
        vehiculosStream.forEach(System.out::println);
                    
    }
    
}
