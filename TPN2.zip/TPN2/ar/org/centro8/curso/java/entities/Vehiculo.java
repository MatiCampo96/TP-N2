package ar.org.centro8.curso.java.entities;

import java.text.DecimalFormat;

public abstract class Vehiculo {

    private String marca;
    private String modelo;
    private float precio;

    public Vehiculo(String marca, String modelo, float precio) {
        this.marca = marca;
        this.modelo = modelo;
        this.precio = precio;
    }

    public String getMarca() {
        return marca;
    }

    public String getModelo() {
        return modelo;
    }

    public float getPrecio() {
        return precio;
    }

    public String getFormatPrecio(){
        DecimalFormat df= new DecimalFormat("###,###,###.00");
        return df.format(precio);
    } 

    @Override
    public abstract String toString();

}
