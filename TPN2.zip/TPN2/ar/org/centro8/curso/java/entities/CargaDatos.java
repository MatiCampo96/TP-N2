package ar.org.centro8.curso.java.entities;

public class CargaDatos {
    public static void main(String[] args) {
        Auto auto1 = new Auto("Peugeot", "206", 200000.00d, 4);
        Moto moto1 = new Moto("Honda", "Titan", 60000.00d, 125);
        Auto auto2 = new Auto("Peugeot", "208", 250000.00d, 5);
        Moto moto2 = new Moto("Yamaha", "YBR", 80500.50d, 160);

        // Pruebas
        System.out.println(auto1.toString());
        System.out.println(moto1.toString());
        System.out.println(auto2.toString());
        System.out.println(moto2.toString());
    }

}
