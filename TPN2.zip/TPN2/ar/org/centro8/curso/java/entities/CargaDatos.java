package ar.org.centro8.curso.java.entities;

import java.util.ArrayList;
import java.util.List;

public class CargaDatos {
    public static void main(String[] args) {
        List vehiculos = new ArrayList<>();
        vehiculos.add(new Auto("Peugeot", "206", 200000.00f, 4));
        vehiculos.add(new Moto("Honda", "Titan", 60000.00f, 125));
        vehiculos.add(new Auto("Peugeot", "208", 250000.00f, 5));
        vehiculos.add(new Moto("Yamaha", "YBR", 80500.50f, 160));

       // vehiculos.forEach(System.out::println);

    
}
