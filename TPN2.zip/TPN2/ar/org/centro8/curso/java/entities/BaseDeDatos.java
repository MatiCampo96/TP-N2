package ar.org.centro8.curso.java.entities;

import java.util.ArrayList;
import java.util.List;

public class BaseDeDatos {

    public static List<Vehiculo> lista = new ArrayList<Vehiculo>();

    public static void carga() {
        lista.add(new Auto("Peugeot", "206", 200000.00d, 4));
        lista.add(new Moto("Honda", "Titan", 60000.00d, 125));
        lista.add(new Auto("Peugeot", "208", 250000.00d, 5));
        lista.add(new Moto("Yamaha", "YBR", 80500.50d, 160));
    }

}
