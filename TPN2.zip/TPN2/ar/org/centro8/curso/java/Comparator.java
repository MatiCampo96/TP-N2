package ar.org.centro8.curso.java;

public class Comparator {

}
