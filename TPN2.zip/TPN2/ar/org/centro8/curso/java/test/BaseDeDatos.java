package ar.org.centro8.curso.java.test;

import java.util.ArrayList;
import java.util.List;

import ar.org.centro8.curso.java.entities.Auto;
import ar.org.centro8.curso.java.entities.Moto;
import ar.org.centro8.curso.java.entities.Vehiculo;

public class BaseDeDatos {

    public static List<Vehiculo> lista = new ArrayList<Vehiculo>();

    public static void dato(){
        lista.add(new Auto("Peugeot", "206", 200000.00d, 4));
        lista.add(new Moto("Honda", "Titan", 60000.00d, 125));
        lista.add(new Auto("Peugeot", "208", 250000.00d, 5));
        lista.add(new Moto("Yamaha", "YBR", 80500.50d, 160));
    }
    
}
