package ar.org.centro8.curso.java.entities;

import static ar.org.centro8.curso.java.entities.BaseDeDatos.*;

import java.util.Comparator;

public class Metodos {
    public static void recorroLista() { // Recorrido
        lista.forEach(System.out::println);
    }

    private static void separador() {
        System.out.println("\n=============================\n");
    }

    public static double mayorCosto() { // Consigue el Precio Maximo
        double precioMaximo = lista
                .stream()
                .max(Comparator.comparing(Vehiculo::getPrecio))
                .get()
                .getPrecio();
        return precioMaximo;
    }

    public static double menorCosto() { // Consigue el Precio Minimo
        double precioMinimo = lista
                .stream()
                .min(Comparator.comparing(Vehiculo::getPrecio))
                .get()
                .getPrecio();
        return precioMinimo;
    }

    // Vehiculo mas caro
    public static void vehiculoMasCaro() {
        lista
                .stream()
                .filter(l -> l.getPrecio() == mayorCosto())
                .forEach(vehiculo -> System.out.println("Vehículo más caro:  "
                        + vehiculo.getMarca() + " " + vehiculo.getModelo()));
    }

    // Vehiculo mas barato
    public static void vehiculoMasBarato() {
        lista
                .stream()
                .filter(l -> l.getPrecio() == menorCosto())
                .forEach(vehiculo -> System.out.println("Vehículo más barato:  "
                        + vehiculo.getMarca() + " " + vehiculo.getModelo()));

    }

    private static void vehiculoQueContieneY() { // Contiene la letra Y
        lista
                .stream()
                .filter(p -> p.getModelo().toLowerCase().contains("y"))
                .forEach(vehiculo -> System.out.println("Vehículo que contiene en el modelo la letra ‘Y’: "
                        + vehiculo.getMarca() + " " + vehiculo.getModelo() + " " + vehiculo.getFormatPrecio()));

    }

    // Vehiculos ordenados por precio de mayor a menor
    private static void VehiculosOrdenadosPorPrecio() {
        System.out.println("Vehículos ordenados por precio de mayor a menor:");

        lista
                .stream()
                .sorted(Comparator.comparingDouble(Vehiculo::getPrecio).reversed())
                .map(vehiculo -> vehiculo.getMarca() + " " + vehiculo.getModelo())
                .forEach(System.out::println);
    }

    // Vehiculos por orden natural
    private static void VehiculosPorOrdenNatural() {
        Comparator<Vehiculo> comparadorMultiple = Comparator.comparing(Vehiculo::getMarca)
                .thenComparing(Comparator.comparing(Vehiculo::getModelo))
                .thenComparing(Comparator.comparingDouble(Vehiculo::getPrecio));

        System.out.println("Vehículos ordenados por orden natural (por marca,modelo,precio):");

        lista
                .stream()
                .sorted(comparadorMultiple)
                .forEach(System.out::println);
    }

}
