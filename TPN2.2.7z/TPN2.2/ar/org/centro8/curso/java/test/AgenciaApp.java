package ar.org.centro8.curso.java.test;

import java.util.stream.Collectors;
import java.util.stream.Stream;
import java.util.Comparator;
import ar.org.centro8.curso.java.entities.Vehiculo;
import static ar.org.centro8.curso.java.entities.BaseDeDatos.lista;
import static ar.org.centro8.curso.java.entities.BaseDeDatos.carga;
import static ar.org.centro8.curso.java.entities.Metodos.*;

public class AgenciaApp {
    public static void main(String[] args) {
        carga();
        recorroLista();
        separador();
        vehiculoMasCaro();
        vehiculoMasBarato();
        vehiculoQueContieneY();
        separador();
        VehiculosOrdenadosPorPrecio();
        separador();
        VehiculosPorOrdenNatural();

    }

}
