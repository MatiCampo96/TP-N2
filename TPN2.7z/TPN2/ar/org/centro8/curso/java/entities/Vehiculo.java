package ar.org.centro8.curso.java.entities;

import java.text.DecimalFormat;

public abstract class Vehiculo implements Comparable<Vehiculo> {

    private final String marca;
    private final String modelo;
    private final double precio;

    public Vehiculo(String marca, String modelo, double precio) {
        this.marca = marca;
        this.modelo = modelo;
        this.precio = precio;
    }

    public String getMarca() {
        return marca;
    }

    public String getModelo() {
        return modelo;
    }

    public double getPrecio() {
        return precio;
    }

    public String getFormatPrecio() {
        DecimalFormat df = new DecimalFormat("$###,###,###.00");
        return df.format(precio);
    }

    @Override
    public abstract String toString();

    @Override
    public int compareTo(Vehiculo v) {
        int salida;

        if (this.precio < v.precio) {
            salida = -1;
        } else {
            if (this.precio > v.precio) {
                salida = 1;
            } else {
                salida = 0;
            }
        }
        return salida;
    }
}
