package ar.org.centro8.curso.java.test;

import java.util.Comparator;
import ar.org.centro8.curso.java.entities.Vehiculo;
import static ar.org.centro8.curso.java.entities.BaseDeDatos.*;

public class AgenciaApp {
    public static void main(String[] args) {
        carga();
        recorroLista();
        separador();
        vehiculoMasCaro();
        vehiculoMasBarato();
        vehiculoQueContieneY();
        separador();
        vehiculosOrdenadosPorPrecio();
        separador();
        vehiculosPorOrdenNatural();

    }

    public static void recorroLista() {
        lista.forEach(System.out::println);
    }

    private static void separador() {
        System.out.println("\n=============================\n");
    }

    public static double mayorCosto() {
        double precioMaximo = lista
                .stream()
                .max(Comparator.comparing(Vehiculo::getPrecio))
                .get()
                .getPrecio();
        return precioMaximo;
    }

    public static double menorCosto() {
        double precioMinimo = lista
                .stream()
                .min(Comparator.comparing(Vehiculo::getPrecio))
                .get()
                .getPrecio();
        return precioMinimo;
    }

    public static void vehiculoMasCaro() {
        lista
                .stream()
                .filter(l -> l.getPrecio() == mayorCosto())
                .forEach(vehiculo -> System.out.println("Vehículo más caro:  "
                        + vehiculo.getMarca() + " " + vehiculo.getModelo()));
    }

    public static void vehiculoMasBarato() {
        lista
                .stream()
                .filter(l -> l.getPrecio() == menorCosto())
                .forEach(vehiculo -> System.out.println("Vehículo más barato:  "
                        + vehiculo.getMarca() + " " + vehiculo.getModelo()));

    }

    private static void vehiculoQueContieneY() {
        lista
                .stream()
                .filter(p -> p.getModelo().toLowerCase().contains("y"))
                .forEach(vehiculo -> System.out.println("Vehículo que contiene en el modelo la letra ‘Y’: "
                        + vehiculo.getMarca() + " " + vehiculo.getModelo() + " " + vehiculo.getFormatPrecio()));

    }

    private static void vehiculosOrdenadosPorPrecio() {
        System.out.println("Vehículos ordenados por precio de mayor a menor:");

        lista
                .stream()
                .sorted(Comparator.comparingDouble(Vehiculo::getPrecio).reversed())
                .map(vehiculo -> vehiculo.getMarca() + " " + vehiculo.getModelo())
                .forEach(System.out::println);
    }

    private static void vehiculosPorOrdenNatural() {
        System.out.println("Vehículos ordenados por orden natural (por marca,modelo,precio):");

        lista
                .stream()
                .sorted()
                .forEach(System.out::println);
    }

}
